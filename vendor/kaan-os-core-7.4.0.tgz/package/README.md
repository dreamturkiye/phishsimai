# @kaan/os-core

Portable Kaan AI operating contracts, deterministic agent evaluations, and the
rc4 source superset. Version 7.4.0 is the first package release with compiled
JavaScript, declarations, explicit exports, and protected release automation.

## Install

Authenticate the private `@kaan` scope with GitHub Packages, then pin an exact
immutable version:

```bash
npm install --save-exact @kaan/os-core@7.4.0
```

Public entry points:

- `@kaan/os-core` — portable runtime and compatibility API
- `@kaan/os-core/ports` — SQL, LLM, deployment, telemetry, and clock contracts
- `@kaan/os-core/evals` — versioned operational-v2 corpus and graders
- `@kaan/os-core/adapters/external` — product/provider-specific rc4 compatibility

Consumer-owned adapter examples and `.npmrc` setup are in
[`docs/consumer-adapters.md`](docs/consumer-adapters.md).

## Verify

```bash
npm ci
npm run check
npm pack --dry-run
```

The release workflow accepts only stable `vX.Y.Z` tags whose exact value equals
`package.json`, reruns all gates, checks that the version is unpublished, and
publishes to GitHub Packages with provenance. Do not publish manually.

