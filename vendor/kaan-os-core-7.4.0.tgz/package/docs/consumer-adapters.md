# Consumer adapters

`@kaan/os-core` owns portable contracts and deterministic logic. Each product
owns infrastructure adapters and injects them through `createCorePorts`.
Core code must not import a product database client, route handler, prompt
library, deployment sequence, or provider SDK.

## Exact-version installation

Configure GitHub Packages for the private `@kaan` scope:

```ini
@kaan:registry=https://npm.pkg.github.com
//npm.pkg.github.com/:_authToken=${NODE_AUTH_TOKEN}
```

Install an immutable exact version (no `^`, `~`, tag, branch, or range):

```bash
npm install --save-exact @kaan/os-core@7.4.0
```

Commit both `package.json` and the lockfile. Renovation and upgrades should
change the exact version in a reviewed pull request.

## SQL

Wrap a parameterized executor. The adapter receives PostgreSQL-style
placeholders and values separately:

```ts
import { createSqlPort } from '@kaan/os-core/ports'

const sql = createSqlPort((text, values) => database.query(text, [...values]))
```

Dialect translation belongs in the consumer. The rc4 TiDB translator remains
under `@kaan/os-core/adapters/external` only for migration compatibility.

## LLM

Implement one product-owned provider policy:

```ts
import { createLlmPort } from '@kaan/os-core/ports'

const llm = createLlmPort(async request => {
  const result = await provider.complete(request)
  return { text: result.text, provider: 'consumer-provider', tokens: result.tokens }
})
```

Prompts and fallback sequences stay outside this package. The legacy
Groq/Gemini/OpenAI chain is an explicit external compatibility adapter.

## Deployment verification

Map the deployment platform response into `DeploymentVerification`. The core
request supplies product ID, expected hostname, and expected commit; it does
not know Vercel projects, aliases, route handlers, or environment variables.

The legacy Vercel verifier requires consumer startup registration and is
available only from `@kaan/os-core/adapters/external`.

## Telemetry and clock

Telemetry is optional and defaults to a no-op. The clock defaults to the system
clock. Inject both in tests and whenever the host has an observability policy:

```ts
import { createClockPort, createTelemetryPort } from '@kaan/os-core/ports'

const clock = createClockPort(() => new Date())
const telemetry = createTelemetryPort(event => logger.info(event))
```

`createCorePorts` validates every required port and freezes the resulting
container. SQL, LLM, and deployment verification have no implicit production
defaults because silently selecting infrastructure is unsafe.
